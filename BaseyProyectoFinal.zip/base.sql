DROP DATABASE IF EXISTS baseNARP;
CREATE DATABASE baseNARP;
USE baseNARP;

CREATE TABLE Persona(
    CI int,
    PRIMARY KEY(CI)
);

CREATE TABLE Empleado(
    CI int,
    Nombre varchar(30) NOT NULL,
    Apellido varchar(30) NOT NULL,
    Contraseña varchar(256) NOT NULL,
    PRIMARY KEY(CI)
);

CREATE TABLE Administrador (
    CI int,
    Nombre varchar(30) NOT NULL,
    Apellido varchar(30) NOT NULL,
    Contraseña varchar(256) NOT NULL,
    PRIMARY KEY(CI)
);

CREATE TABLE Vehiculo(
    ID int AUTO_INCREMENT,
    Fecha_de_ingreso DATE NOT NULL,
    Modelo varchar(50) NOT NULL,
    Marca varchar(50) NOT NULL,
    Anio smallint NOT NULL,
    CI int NOT NULL,
    PRIMARY KEY(ID)
);

ALTER TABLE Empleado ADD FOREIGN KEY (CI) REFERENCES Persona (CI);
ALTER TABLE Administrador ADD FOREIGN KEY (CI) REFERENCES Persona (CI);
ALTER TABLE Vehiculo ADD FOREIGN KEY (CI) REFERENCES Empleado (CI);

INSERT INTO Persona(CI) VALUE (10);
INSERT INTO Administrador(CI, Nombre, Apellido, Contraseña)VALUE (10, "Admin", "Admin", SHA1("Admin"));