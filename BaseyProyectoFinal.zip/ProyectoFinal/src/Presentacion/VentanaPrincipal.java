package Presentacion;

import java.awt.EventQueue;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Persistencia.ConectorBD;

import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class VentanaPrincipal extends JFrame implements ActionListener {

	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;
	
	private JPanel contentPane;
	private JTextField textFieldUsuario;
	private JTextField textFieldContraseña;
	private JTextPane txtpnContraseaDeEmpleado;
	private JButton btnIniciarSesion;

	public static void main(String[] args) {
		
		VentanaPrincipal frame = new VentanaPrincipal();
	}

	public VentanaPrincipal() {
		cn = bases.conectar();
		this.setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 237, 176);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textFieldUsuario = new JTextField();
		textFieldUsuario.setBounds(12, 26, 202, 21);
		contentPane.add(textFieldUsuario);
		textFieldUsuario.setColumns(10);
		
		textFieldContraseña = new JTextField();
		textFieldContraseña.setBounds(12, 71, 202, 21);
		textFieldContraseña.setColumns(10);
		contentPane.add(textFieldContraseña);
		
		JTextPane txtpnUsuarioDeEmpleado = new JTextPane();
		txtpnUsuarioDeEmpleado.setBounds(12, 1, 202, 23);
		txtpnUsuarioDeEmpleado.setEditable(false);
		txtpnUsuarioDeEmpleado.setText("Usuario");
		contentPane.add(txtpnUsuarioDeEmpleado);
		
		txtpnContraseaDeEmpleado = new JTextPane();
		txtpnContraseaDeEmpleado.setBounds(12, 48, 202, 23);
		txtpnContraseaDeEmpleado.setText("Contraseña");
		txtpnContraseaDeEmpleado.setEditable(false);
		contentPane.add(txtpnContraseaDeEmpleado);
		
		btnIniciarSesion = new JButton("Iniciar sesión");
		btnIniciarSesion.setBounds(12, 95, 202, 27);
		contentPane.add(btnIniciarSesion);
		btnIniciarSesion.addActionListener(this);
	}
	
	public String convertirSHA256(String password) {
	    MessageDigest md = null;
	    try {
	        md = MessageDigest.getInstance("SHA-256");
	    } 
	    catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	        return null;
	    }

	    byte[] hash = md.digest(password.getBytes());
	    StringBuffer sb = new StringBuffer();

	    for(byte b : hash) {
	        sb.append(String.format("%02x", b));
	    }

	    return sb.toString();
	}
	
	public void actionPerformed(ActionEvent e) {
		
		
		if (e.getSource().equals(btnIniciarSesion)){
			try {
				st = cn.createStatement();
				rs = st.executeQuery("SELECT * FROM Empleado WHERE Contraseña = SHA1(\'"+textFieldContraseña.getText()+"\') AND Nombre = \'"+textFieldUsuario.getText()+"\';");
				
				while(rs.next()) {
					int ci = rs.getInt(1);
					this.dispose();	
					VentanaEmpleado ventanaempleado = new VentanaEmpleado(ci);
						
					}
				System.out.println("SELECT * FROM Administrador WHERE Contraseña = SHA1(\'"+textFieldContraseña.getText()+"\') AND Nombre = \'"+textFieldUsuario.getText()+"\';");
				st = cn.createStatement();
				rs = st.executeQuery("SELECT * FROM Administrador WHERE Contraseña = SHA1(\'"+textFieldContraseña.getText()+"\') AND Nombre = \'"+textFieldUsuario.getText()+"\';");
				
				
				
				while(rs.next()) {

					this.dispose();
					VentanaAdmin ventanaadmin = new VentanaAdmin();
					
				}
				
				
			} catch (SQLException r) {
				System.out.println(r);
				// TODO: handle exception
			}
			
		}
		
		
	}
	
	
}
