package Presentacion;
import Persistencia.Vehiculo;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JButton;
import javax.swing.DropMode;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import Persistencia.ConectorBD;

public class AltaVehiculo extends JFrame implements ActionListener{

	int cedula;
	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement preparedStmt;
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JButton btnRegresar;
	private JButton btnDarDeAlta;

	public AltaVehiculo(int ci) {
		cn = bases.conectar();
		cedula = ci;
		
		this.setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 209, 301);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(12, 27, 169, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JTextPane txtpnMarca = new JTextPane();
		txtpnMarca.setEditable(false);
		txtpnMarca.setText("Marca");
		txtpnMarca.setBounds(12, 0, 169, 23);
		contentPane.add(txtpnMarca);
		
		JTextPane txtpnModelo = new JTextPane();
		txtpnModelo.setEditable(false);
		txtpnModelo.setText("Modelo");
		txtpnModelo.setBounds(12, 60, 169, 21);
		contentPane.add(txtpnModelo);
		
		textField_1 = new JTextField();
		textField_1.setBounds(12, 93, 169, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JTextPane txtpnAo = new JTextPane();
		txtpnAo.setEditable(false);
		txtpnAo.setText("Año");
		txtpnAo.setBounds(12, 126, 169, 21);
		contentPane.add(txtpnAo);
		
		textField_2 = new JTextField();
		textField_2.setBounds(12, 156, 169, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		btnDarDeAlta = new JButton("Dar de alta");
		btnDarDeAlta.setBounds(12, 189, 169, 27);
		contentPane.add(btnDarDeAlta);
		btnDarDeAlta.addActionListener(this);
		
		btnRegresar = new JButton("Regresar");
		btnRegresar.setBounds(12, 228, 169, 27);
		contentPane.add(btnRegresar);
		btnRegresar.addActionListener(this);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)) {
			
			this.dispose();
			VentanaEmpleado ventanaempleado = new VentanaEmpleado(cedula);
		}
		if (e.getSource().equals(btnDarDeAlta)) {
			if(textField.getText().isBlank() || textField_1.getText().isBlank() || textField_2.getText().isBlank()) {
				System.out.println("Complete todos los campos");
					
			}else if(textField_2.getText().matches(".*[a-z].*")) {
				System.out.println("Mal ahi salamin");
				
			}else {
					String marca = textField.getText();
					String modelo = textField_1.getText();
					int anio = Integer.parseInt(textField_2.getText());
					int ci = cedula;
					
					Vehiculo vehiculo = new Vehiculo(marca,modelo,anio,ci);
					vehiculo.create();
				}
			}
		}
	}

