package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTable;

public class InfoEmpleados extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtInformacionDeEpleados;
	private JButton btnRegresar;
	private JTable table;


	public InfoEmpleados() {
		this.setVisible(true);         
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtInformacionDeEpleados = new JTextField();
		txtInformacionDeEpleados.setEditable(false);
		txtInformacionDeEpleados.setHorizontalAlignment(SwingConstants.CENTER);
		txtInformacionDeEpleados.setText("INFORMACION DE EPLEADOS");
		txtInformacionDeEpleados.setBounds(63, 32, 301, 20);
		contentPane.add(txtInformacionDeEpleados);
		txtInformacionDeEpleados.setColumns(10);
		
		btnRegresar = new JButton("REGRESAR");
		btnRegresar.setBounds(63, 213, 301, 23);
		contentPane.add(btnRegresar);
		
		table = new JTable();
		table.setBounds(63, 65, 301, 137);
		contentPane.add(table);
		btnRegresar.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)){
			this.dispose();
	        VentanaAdmin ventanaAdmin = new VentanaAdmin();		}
}
}
