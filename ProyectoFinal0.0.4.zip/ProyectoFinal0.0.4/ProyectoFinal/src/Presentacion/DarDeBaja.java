package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;

public class DarDeBaja extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtCedula;
	private JTextField textField_2;
	private JButton btnRegresar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DarDeBaja frame = new DarDeBaja();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DarDeBaja() {
		this.setVisible(true);         
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 234, 192);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtCedula = new JTextField();
		txtCedula.setText("Cedula");
		txtCedula.setHorizontalAlignment(SwingConstants.CENTER);
		txtCedula.setEditable(false);
		txtCedula.setColumns(10);
		txtCedula.setBounds(10, 11, 194, 20);
		contentPane.add(txtCedula);
		
		textField_2 = new JTextField();
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setColumns(10);
		textField_2.setBounds(10, 42, 194, 20);
		contentPane.add(textField_2);
		
		JButton btnNewButton = new JButton("Dar de baja a empleado");
		btnNewButton.setBounds(10, 73, 194, 23);
		contentPane.add(btnNewButton);
		
		btnRegresar = new JButton("REGRESAR");
		btnRegresar.setBounds(10, 107, 194, 23);
		contentPane.add(btnRegresar);
		btnRegresar.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)){
			this.dispose();
			VentanaAdmin admin = new VentanaAdmin();
		}
	}
}
