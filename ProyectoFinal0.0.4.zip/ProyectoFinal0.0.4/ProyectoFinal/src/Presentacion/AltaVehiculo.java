package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JButton;
import javax.swing.DropMode;

public class AltaVehiculo extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JButton btnRegresar;

	public AltaVehiculo() {
		this.setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 209, 301);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(12, 27, 169, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JTextPane txtpnMarca = new JTextPane();
		txtpnMarca.setEditable(false);
		txtpnMarca.setText("Marca");
		txtpnMarca.setBounds(12, 0, 169, 23);
		contentPane.add(txtpnMarca);
		
		JTextPane txtpnModelo = new JTextPane();
		txtpnModelo.setEditable(false);
		txtpnModelo.setText("Modelo");
		txtpnModelo.setBounds(12, 60, 169, 21);
		contentPane.add(txtpnModelo);
		
		textField_1 = new JTextField();
		textField_1.setBounds(12, 93, 169, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JTextPane txtpnAo = new JTextPane();
		txtpnAo.setEditable(false);
		txtpnAo.setText("Año");
		txtpnAo.setBounds(12, 126, 169, 21);
		contentPane.add(txtpnAo);
		
		textField_2 = new JTextField();
		textField_2.setBounds(12, 156, 169, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnDarDeAlta = new JButton("Dar de alta");
		btnDarDeAlta.setBounds(12, 189, 169, 27);
		contentPane.add(btnDarDeAlta);
		
		btnRegresar = new JButton("Regresar");
		btnRegresar.setBounds(12, 228, 169, 27);
		contentPane.add(btnRegresar);
		btnRegresar.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)) {
			this.dispose();
			VentanaEmpleado ventanaempleado = new VentanaEmpleado();
		}
		
	}

}
