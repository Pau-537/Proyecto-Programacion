package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;

public class DarDeAlta extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNombre;
	private JTextField textField;
	private JTextField txtCedula;
	private JTextField textField_2;
	private JButton btnRegresar;
	private JTextField textField_1;
	private JTextField txtContrasea;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DarDeAlta frame = new DarDeAlta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DarDeAlta() {
		this.setVisible(true);         
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 233, 237);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtNombre = new JTextField();
		txtNombre.setEditable(false);
		txtNombre.setHorizontalAlignment(SwingConstants.CENTER);
		txtNombre.setText("Nombre");
		txtNombre.setBounds(10, 11, 86, 20);
		contentPane.add(txtNombre);
		txtNombre.setColumns(10);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setColumns(10);
		textField.setBounds(10, 42, 86, 20);
		contentPane.add(textField);
		
		txtCedula = new JTextField();
		txtCedula.setText("Apellido");
		txtCedula.setHorizontalAlignment(SwingConstants.CENTER);
		txtCedula.setEditable(false);
		txtCedula.setColumns(10);
		txtCedula.setBounds(118, 11, 86, 20);
		contentPane.add(txtCedula);
		
		textField_2 = new JTextField();
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setColumns(10);
		textField_2.setBounds(118, 42, 86, 20);
		contentPane.add(textField_2);
		
		JButton btnNewButton = new JButton("Dar de alta a empleado");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(10, 135, 194, 23);
		contentPane.add(btnNewButton);
		
		btnRegresar = new JButton("REGRESAR");
		btnRegresar.setBounds(10, 169, 194, 23);
		contentPane.add(btnRegresar);
		
		textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setColumns(10);
		textField_1.setBounds(10, 104, 86, 20);
		contentPane.add(textField_1);
		
		txtContrasea = new JTextField();
		txtContrasea.setText("Contraseña");
		txtContrasea.setHorizontalAlignment(SwingConstants.CENTER);
		txtContrasea.setEditable(false);
		txtContrasea.setColumns(10);
		txtContrasea.setBounds(10, 73, 86, 20);
		contentPane.add(txtContrasea);
		
		textField_4 = new JTextField();
		textField_4.setText("Cedula");
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setEditable(false);
		textField_4.setColumns(10);
		textField_4.setBounds(118, 73, 86, 20);
		contentPane.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setHorizontalAlignment(SwingConstants.CENTER);
		textField_5.setColumns(10);
		textField_5.setBounds(118, 104, 86, 20);
		contentPane.add(textField_5);
		btnRegresar.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)){
			this.dispose();
			VentanaAdmin admin = new VentanaAdmin();
		}
}
}

