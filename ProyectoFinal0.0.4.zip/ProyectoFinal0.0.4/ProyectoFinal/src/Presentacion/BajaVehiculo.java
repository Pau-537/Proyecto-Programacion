package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import java.awt.BorderLayout;
import javax.swing.JButton;

public class BajaVehiculo extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JButton btnRegresar;
	
	
	public BajaVehiculo() {
		this.setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100,290, 290);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		getContentPane().setLayout(null);
		
		JTextPane txtpnVehiculo = new JTextPane();
		txtpnVehiculo.setBounds(28, 59, 223, 23);
		txtpnVehiculo.setText("ID del vehiculo");
		txtpnVehiculo.setEditable(false);
		getContentPane().add(txtpnVehiculo);
		
		textField = new JTextField();
		textField.setBounds(28, 94, 223, 23);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Dar de baja");
		btnNewButton.setBounds(28, 129, 223, 23);
		getContentPane().add(btnNewButton);
		
		btnRegresar = new JButton("Regresar");
		btnRegresar.setBounds(28, 161, 223, 23);
		getContentPane().add(btnRegresar);
		btnRegresar.addActionListener(this);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)) {
			this.dispose();
			VentanaEmpleado ventanaempleado= new VentanaEmpleado();
		}
		
	}
}
