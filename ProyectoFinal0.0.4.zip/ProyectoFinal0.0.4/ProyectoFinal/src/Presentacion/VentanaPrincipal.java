package Presentacion;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField textFieldUsuario;
	private JTextField textFieldContraseña;
	private JTextPane txtpnContraseaDeEmpleado;
	private JButton btnIniciarSesion;

	public static void main(String[] args) {
		VentanaPrincipal frame = new VentanaPrincipal();
		frame.setVisible(true);
	}

	public VentanaPrincipal() {
		this.setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 237, 176);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textFieldUsuario = new JTextField();
		textFieldUsuario.setBounds(12, 26, 202, 21);
		contentPane.add(textFieldUsuario);
		textFieldUsuario.setColumns(10);
		
		textFieldContraseña = new JTextField();
		textFieldContraseña.setColumns(10);
		textFieldContraseña.setBounds(12, 71, 202, 21);
		contentPane.add(textFieldContraseña);
		
		JTextPane txtpnUsuarioDeEmpleado = new JTextPane();
		txtpnUsuarioDeEmpleado.setEditable(false);
		txtpnUsuarioDeEmpleado.setText("Usuario");
		txtpnUsuarioDeEmpleado.setBounds(12, 1, 202, 23);
		contentPane.add(txtpnUsuarioDeEmpleado);
		
		txtpnContraseaDeEmpleado = new JTextPane();
		txtpnContraseaDeEmpleado.setText("Contraseña");
		txtpnContraseaDeEmpleado.setEditable(false);
		txtpnContraseaDeEmpleado.setBounds(12, 48, 202, 23);
		contentPane.add(txtpnContraseaDeEmpleado);
		
		btnIniciarSesion = new JButton("Iniciar sesión");
		btnIniciarSesion.setBounds(12, 95, 202, 27);
		contentPane.add(btnIniciarSesion);
		btnIniciarSesion.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		
		
		if (e.getSource().equals(btnIniciarSesion)){
			
			/*
			 * Puse un usuario y contraseña temporal hasta implementar la base de datos
			 * 
			 * Empleado
			 * Usuario temporal --> Carlos
			 * Contraseña temporal --> 1234
			 * 
			 * Admin
			 * Usuario temporal --> Jose
			 * Contraseña temporal --> 4321
			 */
			
			if (textFieldUsuario.getText().contentEquals("Carlos") && textFieldContraseña.getText().contentEquals("1234")){
				this.dispose();
				VentanaEmpleado ventanaempleado = new VentanaEmpleado();
			}else if (textFieldUsuario.getText().contentEquals("Jose") && textFieldContraseña.getText().contentEquals("4321")){
				this.dispose();
				VentanaAdmin ventanaadmin = new VentanaAdmin();
			} else {
				System.out.println("Error, usuario o contraseña incorrecta");
			}
			
		}
		
		
	}
	
	
}
