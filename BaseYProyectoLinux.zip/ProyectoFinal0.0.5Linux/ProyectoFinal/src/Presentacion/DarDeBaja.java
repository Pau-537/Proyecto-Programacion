package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Persistencia.ConectorBD;
import Persistencia.Empleado;

import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;

public class DarDeBaja extends JFrame implements ActionListener{

	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement preparedStmt;
	
	private JButton btnBaja;
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtCedula;
	private JTextField textField_2;
	private JButton btnRegresar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DarDeBaja frame = new DarDeBaja();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DarDeBaja() {
		this.setVisible(true);         
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 234, 192);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtCedula = new JTextField();
		txtCedula.setText("Cedula");
		txtCedula.setHorizontalAlignment(SwingConstants.CENTER);
		txtCedula.setEditable(false);
		txtCedula.setColumns(10);
		txtCedula.setBounds(10, 11, 194, 20);
		contentPane.add(txtCedula);
		
		textField_2 = new JTextField();
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setColumns(10);
		textField_2.setBounds(10, 42, 194, 20);
		contentPane.add(textField_2);
		
		btnBaja = new JButton("Dar de baja a empleado");
		btnBaja.setBounds(10, 73, 194, 23);
		contentPane.add(btnBaja);
		btnBaja.addActionListener(this);
		
		btnRegresar = new JButton("REGRESAR");
		btnRegresar.setBounds(10, 107, 194, 23);
		contentPane.add(btnRegresar);
		btnRegresar.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)){
			this.dispose();
			VentanaAdmin admin = new VentanaAdmin();
		}
		if (e.getSource().equals(btnBaja)){
			System.out.println("Caca");
			if(!textField_2.getText().isBlank()) {
				int ci = Integer.parseInt(textField_2.getText());
				Empleado empleado = new Empleado();
				empleado.setCi(ci);
				empleado.delete();
				/*try {
					int id = Integer.parseInt(textField_2.getText());
					String sql = "DELETE FROM empleado WHERE CI=?;";
					String sql2 = "DELETE FROM persona WHERE CI=?;";

					st = cn.createStatement();
					preparedStmt = cn.prepareStatement(sql);
					preparedStmt.setInt (1, id);
					preparedStmt.execute();
					preparedStmt = cn.prepareStatement(sql2);
					preparedStmt.setInt (1, id);
					preparedStmt.execute();
					//"INSERT INTO vehiculo(Fecha_de_ingreso, Modelo, Marca, Anio, CI) VALUE (CURDATE(), "+modelo+", "+marca+", "+anio+", "+ci+");"
					
				}catch (SQLException r){
					System.out.println(r);
				}*/
			}
		}
	}
}