package Presentacion;

import java.awt.EventQueue;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Persistencia.ConectorBD;

import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class VentanaPrincipal extends JFrame implements ActionListener {

	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;
	
	private JPanel contentPane;
	private JTextField textFieldUsuario;
	private JTextField textFieldContraseña;
	private JTextPane txtpnContraseaDeEmpleado;
	private JButton btnIniciarSesion;

	public static void main(String[] args) {
		
		VentanaPrincipal frame = new VentanaPrincipal();
		frame.setVisible(true);
	}

	public VentanaPrincipal() {
		cn = bases.conectar();
		this.setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 237, 176);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textFieldUsuario = new JTextField();
		textFieldUsuario.setBounds(12, 26, 202, 21);
		contentPane.add(textFieldUsuario);
		textFieldUsuario.setColumns(10);
		
		textFieldContraseña = new JTextField();
		textFieldContraseña.setColumns(10);
		textFieldContraseña.setBounds(12, 71, 202, 21);
		contentPane.add(textFieldContraseña);
		
		JTextPane txtpnUsuarioDeEmpleado = new JTextPane();
		txtpnUsuarioDeEmpleado.setEditable(false);
		txtpnUsuarioDeEmpleado.setText("Usuario");
		txtpnUsuarioDeEmpleado.setBounds(12, 1, 202, 23);
		contentPane.add(txtpnUsuarioDeEmpleado);
		
		txtpnContraseaDeEmpleado = new JTextPane();
		txtpnContraseaDeEmpleado.setText("Contraseña");
		txtpnContraseaDeEmpleado.setEditable(false);
		txtpnContraseaDeEmpleado.setBounds(12, 48, 202, 23);
		contentPane.add(txtpnContraseaDeEmpleado);
		
		btnIniciarSesion = new JButton("Iniciar sesión");
		btnIniciarSesion.setBounds(12, 95, 202, 27);
		contentPane.add(btnIniciarSesion);
		btnIniciarSesion.addActionListener(this);
	}
	
	public String convertirSHA256(String password) {
	    MessageDigest md = null;
	    try {
	        md = MessageDigest.getInstance("SHA-256");
	    } 
	    catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	        return null;
	    }

	    byte[] hash = md.digest(password.getBytes());
	    StringBuffer sb = new StringBuffer();

	    for(byte b : hash) {
	        sb.append(String.format("%02x", b));
	    }

	    return sb.toString();
	}
	
	public void actionPerformed(ActionEvent e) {
		
		
		if (e.getSource().equals(btnIniciarSesion)){
			try {
				st = cn.createStatement();
				rs = st.executeQuery("SELECT * FROM Empleado");
				
				while(rs.next()) {
					int ci = rs.getInt(1);
					String nombre = rs.getString(2);
					String contra = rs.getString(4);
					String pass = convertirSHA256(textFieldContraseña.getText());
					if (textFieldUsuario.getText().contentEquals(nombre) && pass.contentEquals(contra)){
						this.dispose();
						
						VentanaEmpleado ventanaempleado = new VentanaEmpleado(ci);
					}else {
						
					}
				}
				
				st = cn.createStatement();
				rs = st.executeQuery("SELECT * FROM Administrador");
				
				while(rs.next()) {
					int ci = rs.getInt(1);
					String nombre = rs.getString(2);
					String contra = rs.getString(4);
					String pass = convertirSHA256(textFieldContraseña.getText());
					if (textFieldUsuario.getText().contentEquals(nombre) && pass.contentEquals(contra)){
						this.dispose();
						VentanaAdmin ventanaadmin = new VentanaAdmin();
					} else {
						System.out.println(convertirSHA256("Admin"));
					}
					
				}
				
				
			} catch (SQLException r) {
				System.out.println(r);
				// TODO: handle exception
			}
			
		}
		
		
	}
	
	
}
