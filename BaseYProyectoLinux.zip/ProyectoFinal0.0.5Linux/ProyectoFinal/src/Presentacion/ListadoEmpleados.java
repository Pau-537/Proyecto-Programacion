package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class ListadoEmpleados extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtListaDeEmpleados;
	private JButton btnRegresar;
	private JTable table;

	
	public ListadoEmpleados() {
		this.setVisible(true);         
		setResizable(false);		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtListaDeEmpleados = new JTextField();
		txtListaDeEmpleados.setEditable(false);
		txtListaDeEmpleados.setText("LISTA DE EMPLEADOS");
		txtListaDeEmpleados.setHorizontalAlignment(SwingConstants.CENTER);
		txtListaDeEmpleados.setBounds(135, 11, 153, 20);
		contentPane.add(txtListaDeEmpleados);
		txtListaDeEmpleados.setColumns(10);
		
		btnRegresar = new JButton("REGRESAR");
		btnRegresar.setBounds(135, 206, 153, 23);
		contentPane.add(btnRegresar);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"Mersedes","1","1900"},
			},
			new String[] {
				"Marca", "Modelo", "A\u00F1o"
				
			}
		) {
			Class[] columnTypes = new Class[] {
				Object.class, String.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setToolTipText("");
		table.setBounds(12, 42, 418, 153);
		contentPane.add(table);
		btnRegresar.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)){
			
			this.dispose();
	        VentanaAdmin ventanaAdmin = new VentanaAdmin();		
	        }
	}
}
