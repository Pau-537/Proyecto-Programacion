package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Persistencia.Vehiculo;

import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTable;

public class ListadoVehiculos extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtListaDeEmpleados;
	private JButton btnRegresar;
	private JTable table;
	DefaultTableModel model = new DefaultTableModel();
	static int cedula = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListadoVehiculos frame = new ListadoVehiculos(cedula);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ListadoVehiculos(int ci) {
		cedula = ci;
		this.setVisible(true);         
		setResizable(false);		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtListaDeEmpleados = new JTextField();
		txtListaDeEmpleados.setEditable(false);
		txtListaDeEmpleados.setText("LISTA DE VEHICULOS");
		txtListaDeEmpleados.setHorizontalAlignment(SwingConstants.CENTER);
		txtListaDeEmpleados.setBounds(135, 11, 153, 20);
		contentPane.add(txtListaDeEmpleados);
		txtListaDeEmpleados.setColumns(10);
		
		btnRegresar = new JButton("REGRESAR");
		btnRegresar.setBounds(135, 206, 153, 23);
		contentPane.add(btnRegresar);
		
		table = new JTable();
		table.setBounds(12, 42, 418, 153);
		contentPane.add(table);
		btnRegresar.addActionListener(this);
		model.addColumn("Id");
		model.addColumn("Marca");
		model.addColumn("Modelo");
		model.addColumn("Año");
		model.addColumn("Fecha Ingreso");
		actualizarTabla();
	
	}

	public void actualizarTabla() {
		while (model.getRowCount() > 0) {
			model.removeRow(0);
		}
		Vehiculo vehiculo = new Vehiculo ();
		ArrayList<Vehiculo> lista = vehiculo.read(cedula);
		for(Vehiculo v : lista) {
			Object fila[] = new Object[5];
			fila[0] = v.getId();
			fila[1] = v.getMarca();
			fila[2] = v.getModelo();
			fila[3] = v.getAño();
			fila[4] = v.getFecha();
			model.addRow(fila);
		}
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"Marca", "Modelo", "A\u00F1o"
			}
		));
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)){
			this.dispose();
	        VentanaEmpleado ventanaempleado = new VentanaEmpleado(cedula);		}
		
	}
}

