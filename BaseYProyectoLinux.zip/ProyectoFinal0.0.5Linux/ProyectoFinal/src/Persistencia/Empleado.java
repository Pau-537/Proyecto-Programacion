package Persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Presentacion.VentanaAdmin;
import Presentacion.VentanaEmpleado;

public class Empleado {
	
	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement preparedStmt;
	
	private int ci;
	private String nombre, apellido, pass;
	public Empleado() {
		cn = bases.conectar();
	}
	public Empleado(int cedula, String no, String ap, String contrasena) {
		this.ci = cedula;
		this.nombre= no;
		this.apellido = ap;
		this.pass = contrasena;
		cn = bases.conectar();
	}
	public int getCi() {
		return ci;
	}
	public String getNombre() {
		return nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public String getPassword() {
		return pass;
	}
	public void setCi(int cedula) {
		this.ci = cedula;
	}
	public void setNombre(String nom) {
		this.nombre = nom;
	}
	public void setAp(String ap) {
		this.apellido = ap;
	}
	public void setPass(String contrasena) {
		this.pass = contrasena;
	}
	public boolean create() {
		try {
			Persona persona = new Persona(ci);
			boolean resultado = persona.create();
			if (!resultado) {
				return false;
			}
			String sql = "INSERT INTO empleado(CI, Nombre, Apellido, Contraseña) VALUE (?, ?, ?, ?);";
			preparedStmt = cn.prepareStatement(sql);
			preparedStmt.setInt (1, ci);
			preparedStmt.setString (2, nombre);
			preparedStmt.setString (3, apellido);
			preparedStmt.setString (4, pass);
			preparedStmt.execute();
			
		}catch (SQLException r){
			System.out.println(r);
			return false;
		}
		return true;
	}
	public boolean delete() {
		// Comprobar si el usuario existe
		try {
			st = cn.createStatement();
			rs = st.executeQuery("SELECT * FROM empleado WHERE CI="+this.ci+";");
			System.out.println(rs);
		} catch (SQLException r) {
			System.out.println(r);
			// TODO: handle exception
		}
		// Eliminar el usuario
		
		// Eliminar persona
		return true;
	}
}