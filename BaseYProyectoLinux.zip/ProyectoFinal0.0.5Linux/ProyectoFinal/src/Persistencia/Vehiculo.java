package Persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class Vehiculo {
	private int id, fecha_ingreso, anio, ci;
	private String modelo,marca;
	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement preparedStmt;
	public Vehiculo() {
		cn = bases.conectar();
	}
	public Vehiculo(int id, int fecha_ing, String marca, String modelo, int anio, int ci) {
		this.id = id;
		this.fecha_ingreso = fecha_ing;
		this.marca = marca;
		this.modelo = modelo;
		this.anio = anio;
		this.ci = ci;
		cn = bases.conectar();
	}
	public int getId() {
		return this.id;
	}
	public int getFecha() {
		return this.fecha_ingreso;
	}
	public String getMarca() {
		return this.marca;
	}
	public String getModelo() {
		return this.modelo;
	}
	public int getAño() {
		return this.anio;
	}
	public int getCi() {
		return this.ci;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setFecha(int fecha) {
		this.fecha_ingreso = fecha;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public void setAño(int año) {
		this.anio = año;
	}
	public void setCi(int Ci) {
		this.ci = Ci;
	}
	
	public  ArrayList read(int cedula) {
		ArrayList <Vehiculo> array= new ArrayList();
		try {
			st = cn.createStatement();
			rs = st.executeQuery("SELECT * FROM Vehiculo");
			while(rs.next()) {
				Vehiculo v = new Vehiculo();;
				v.setMarca(rs.getString("marca"));
				v.setModelo(rs.getString("Modelo"));
				v.setAño(rs.getInt("anio"));
				v.setId(rs.getInt("Id"));
				v.setCi(rs.getInt("CI"));
				v.setFecha(rs.getInt("Fecha_de_ingreso"));
				array.add (v);
			}
			cn.close();
			cn=null;		
			}catch (SQLException r){
				System.out.println(r);
				
			}
		return array;
	}
}
