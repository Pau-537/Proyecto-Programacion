package Persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Persona {
    int ci;
    ConectorBD bases = new ConectorBD();
    Connection cn = null;
    Statement st = null;
    ResultSet rs = null;
    PreparedStatement preparedStmt;

    public Persona() {
    	cn = bases.conectar();
    }
    public Persona(int cedula) {
    	cn = bases.conectar();
        this.ci = cedula;
    }

    public int getCi() {
        return ci;
    }
    public void setCi(int cedula) {
        this.ci = cedula;
    }
    public boolean create() {
        try {
            String sql = "INSERT INTO persona(CI) VALUE (?);";
            st = cn.createStatement();
            preparedStmt = cn.prepareStatement(sql);
            preparedStmt.setInt (1, ci);
            preparedStmt.execute();
        } catch(SQLException r) {
            System.out.println(r);
            return false;
        }
        return true;
    }
}
