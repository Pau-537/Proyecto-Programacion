package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Persistencia.ConectorBD;

import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextPane;
import java.awt.Font;

public class InfoEmpleados extends JFrame implements ActionListener{
	
	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JButton btnRegresar;
	private JTextField txtFieldCI;
	private JButton btnBuscar;
	private JTextPane txtPaneVehiculo;
	private JTextPane txtPaneApellido;
	private JTextPane txtPaneNombre;

	public InfoEmpleados() {
		cn = bases.conectar();
		this.setVisible(true);         
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 420, 374);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		btnRegresar = new JButton("Regresar");
		btnRegresar.setBounds(6, 301, 388, 23);
		contentPane.add(btnRegresar);
		btnRegresar.addActionListener(this);
		
		txtFieldCI = new JTextField();
		txtFieldCI.setBounds(8, 47, 386, 23);
		contentPane.add(txtFieldCI);
		txtFieldCI.setColumns(10);
		
		txtPaneApellido = new JTextPane();
		txtPaneApellido.setEditable(false);
		txtPaneApellido.setBounds(6, 174, 388, 20);
		contentPane.add(txtPaneApellido);
		
		JTextPane txtpnVehiculoActual = new JTextPane();
		txtpnVehiculoActual.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtpnVehiculoActual.setText("Vehiculo actual");
		txtpnVehiculoActual.setEditable(false);
		txtpnVehiculoActual.setBounds(6, 205, 388, 20);
		contentPane.add(txtpnVehiculoActual);
		
		txtPaneVehiculo = new JTextPane();
		txtPaneVehiculo.setEditable(false);
		txtPaneVehiculo.setBounds(6, 236, 388, 20);
		contentPane.add(txtPaneVehiculo);
		
		JTextPane txtpnApellidoDelEmpleado = new JTextPane();
		txtpnApellidoDelEmpleado.setFont(new Font("Tahoma", Font.BOLD, 11));
		txtpnApellidoDelEmpleado.setText("Apellido del empleado");
		txtpnApellidoDelEmpleado.setEditable(false);
		txtpnApellidoDelEmpleado.setBounds(6, 143, 388, 20);
		contentPane.add(txtpnApellidoDelEmpleado);
		
		txtPaneNombre = new JTextPane();
		txtPaneNombre.setEditable(false);
		txtPaneNombre.setBounds(6, 112, 388, 20);
		contentPane.add(txtPaneNombre);
		
		JTextPane textPane_1_4 = new JTextPane();
		textPane_1_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		textPane_1_4.setText("Nombre del empleado (usuario)");
		textPane_1_4.setEditable(false);
		textPane_1_4.setBounds(6, 81, 388, 20);
		contentPane.add(textPane_1_4);
		
		JTextPane textPane_1_5 = new JTextPane();
		textPane_1_5.setFont(new Font("Tahoma", Font.BOLD, 11));
		textPane_1_5.setText("Ingrese la cedula del empleado");
		textPane_1_5.setEditable(false);
		textPane_1_5.setBounds(8, 16, 386, 20);
		contentPane.add(textPane_1_5);
		
		btnBuscar = new JButton("Buscar");
		btnBuscar.setBounds(6, 267, 388, 23);
		contentPane.add(btnBuscar);
		btnBuscar.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)){
			this.dispose();
	        VentanaAdmin ventanaAdmin = new VentanaAdmin();		}
		if (e.getSource().equals(btnBuscar)) {
			try {
			st = cn.createStatement();
			rs = st.executeQuery("SELECT * FROM Empleado WHERE CI= "+Integer.parseInt(txtFieldCI.getText())+";");
			System.out.println("SELECT * FROM Empleado WHERE CI= "+Integer.parseInt(txtFieldCI.getText())+";");
			
			while (rs.next()) {
			
			txtPaneNombre.setText(rs.getString(2));
			txtPaneApellido.setText(rs.getString(3));
			}
			
			rs = st.executeQuery("SELECT * FROM Vehiculo WHERE CI= "+Integer.parseInt(txtFieldCI.getText())+"");
			while(rs.next()) {
			txtPaneVehiculo.setText(rs.getString(4)+" "+rs.getString(3)+" año "+rs.getString(5));
			}
			cn.close();
			cn=null;	
			
			}catch (SQLException r){
				System.out.println(r);
			}
		}
}
}
