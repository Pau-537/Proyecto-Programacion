package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Persistencia.ConectorBD;

import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;

import Persistencia.Empleado;

public class DarDeAlta extends JFrame implements ActionListener{

	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement preparedStmt;
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNombre;
	private JTextField textField;
	private JTextField txtCedula;
	private JTextField textField_2;
	private JButton btnRegresar;
	private JButton btnAlta;
	private JTextField textField_1;
	private JTextField txtContrasea;
	private JTextField textField_4;
	private JTextField textField_5;


	public DarDeAlta() {
		cn = bases.conectar();
		this.setVisible(true);         
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 233, 237);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtNombre = new JTextField();
		txtNombre.setEditable(false);
		txtNombre.setHorizontalAlignment(SwingConstants.CENTER);
		txtNombre.setText("Nombre");
		txtNombre.setBounds(10, 11, 86, 20);
		contentPane.add(txtNombre);
		txtNombre.setColumns(10);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setColumns(10);
		textField.setBounds(10, 42, 86, 20);
		contentPane.add(textField);
		
		txtCedula = new JTextField();
		txtCedula.setText("Apellido");
		txtCedula.setHorizontalAlignment(SwingConstants.CENTER);
		txtCedula.setEditable(false);
		txtCedula.setColumns(10);
		txtCedula.setBounds(118, 11, 86, 20);
		contentPane.add(txtCedula);
		
		textField_2 = new JTextField();
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setColumns(10);
		textField_2.setBounds(118, 42, 86, 20);
		contentPane.add(textField_2);
		
		btnAlta = new JButton("Dar de alta a empleado");
		btnAlta.addActionListener(this);
		btnAlta.setBounds(10, 135, 194, 23);
		contentPane.add(btnAlta);
		
		btnRegresar = new JButton("REGRESAR");
		btnRegresar.setBounds(10, 169, 194, 23);
		contentPane.add(btnRegresar);
		
		textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setColumns(10);
		textField_1.setBounds(10, 104, 86, 20);
		contentPane.add(textField_1);
		
		txtContrasea = new JTextField();
		txtContrasea.setText("Contraseña");
		txtContrasea.setHorizontalAlignment(SwingConstants.CENTER);
		txtContrasea.setEditable(false);
		txtContrasea.setColumns(10);
		txtContrasea.setBounds(10, 73, 86, 20);
		contentPane.add(txtContrasea);
		
		textField_4 = new JTextField();
		textField_4.setText("Cedula");
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setEditable(false);
		textField_4.setColumns(10);
		textField_4.setBounds(118, 73, 86, 20);
		contentPane.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setHorizontalAlignment(SwingConstants.CENTER);
		textField_5.setColumns(10);
		textField_5.setBounds(118, 104, 86, 20);
		contentPane.add(textField_5);
		btnRegresar.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)){
			this.dispose();
			VentanaAdmin admin = new VentanaAdmin();
			
		}
		if (e.getSource().equals(btnAlta)) {
			if(textField.getText().isBlank() || textField_1.getText().isBlank() || textField_2.getText().isBlank() || textField_5.getText().isBlank()) {
				System.out.println("Complete todos los campos");
					
			}else if(textField_5.getText().matches(".*[a-z].*")) {
				System.out.println("La cedula debe ser un numero");
				
			}else {
				int ci = Integer.parseInt(textField_5.getText());
				String nombre = textField.getText();
				String apellido = textField_2.getText();
				String password = textField_1.getText();
				Empleado empleado = new Empleado(ci,nombre,apellido, password);
				empleado.create();
			}
		}
}
}

