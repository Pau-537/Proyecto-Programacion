package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Persistencia.ConectorBD;
import Persistencia.Vehiculo;

import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTable;

public class ListadoVehiculos extends JFrame implements ActionListener{

	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtListaDeEmpleados;
	private JButton btnRegresar;
	private JTable table;
	DefaultTableModel model = new DefaultTableModel();
	static int cedula = 0;
	
	Object[][] vehiculos = new Object[0][0];
	int cantidadDeVehiculos = 0;

	public ListadoVehiculos(int ci) {
		cn = bases.conectar();
		cedula = ci;
		System.out.println(cedula);
		this.setVisible(true);         
		setResizable(false);		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtListaDeEmpleados = new JTextField();
		txtListaDeEmpleados.setEditable(false);
		txtListaDeEmpleados.setText("LISTA DE VEHICULOS");
		txtListaDeEmpleados.setHorizontalAlignment(SwingConstants.CENTER);
		txtListaDeEmpleados.setBounds(135, 11, 153, 20);
		contentPane.add(txtListaDeEmpleados);
		txtListaDeEmpleados.setColumns(10);
		
		btnRegresar = new JButton("REGRESAR");
		btnRegresar.setBounds(135, 206, 153, 23);
		contentPane.add(btnRegresar);
		
		
		try {
			st = cn.createStatement();
			rs = st.executeQuery("SELECT * FROM Vehiculo WHERE CI ="+cedula);
			
			while(rs.next()) {
				cantidadDeVehiculos = rs.getRow();
			}
			
			vehiculos = new Object[cantidadDeVehiculos][5];
			
			int i = 0;
			rs = st.executeQuery("SELECT * FROM Vehiculo WHERE CI ="+cedula);
			
			while(rs.next()) {
				vehiculos[i][0] = rs.getInt(1);
				vehiculos[i][4] = rs.getDate(2);
				vehiculos[i][1] = rs.getString(3);
				vehiculos[i][2] = rs.getString(4);
				vehiculos[i][3] = rs.getString(5);
				i++;
			}
		}catch (SQLException r) {
			System.out.println(r);
			// TODO: handle exception
		}
		table = new JTable();
		table.setColumnSelectionAllowed(true);
		table.setModel(new DefaultTableModel(
			vehiculos,
			new String[] {
				"ID", "Fecha de ingreso", "Modelo", "Marca", "Año"
			}
		) {
			private static final long serialVersionUID = 1L;

			Class[] columnTypes = new Class[] {
				String.class, String.class, int.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table.setBounds(12, 42, 418, 153);
		contentPane.add(table);
		btnRegresar.addActionListener(this);
	
	}

	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)){
			this.dispose();
	        VentanaEmpleado ventanaempleado = new VentanaEmpleado(cedula);		}
		
	}
}

