package Persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Presentacion.VentanaAdmin;
import Presentacion.VentanaEmpleado;

public class Empleado {
	
	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement preparedStmt;
	
	private int ci;
	private String nombre, apellido, pass;
	public Empleado() {
		cn = bases.conectar();
	}
	public Empleado(int ci) {
		cn = bases.conectar();
		this.ci=ci;
	}
	public Empleado(int cedula, String no, String ap, String contrasena) {
		this.ci = cedula;
		this.nombre= no;
		this.apellido = ap;
		this.pass = contrasena;
		cn = bases.conectar();
	}
	public int getCi() {
		return ci;
	}
	public String getNombre() {
		return nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public String getPassword() {
		return pass;
	}
	public void setCi(int cedula) {
		this.ci = cedula;
	}
	public void setNombre(String nom) {
		this.nombre = nom;
	}
	public void setAp(String ap) {
		this.apellido = ap;
	}
	public void setPass(String contrasena) {
		this.pass = contrasena;
	}
	
	/**
     * Este metodo permite insertar este empleado a la base de datos
     */
	public boolean create() {
		try {
			Persona persona = new Persona(ci);
			boolean resultado = persona.create();
			if (!resultado) {
				return false;
			}
			String sql = "INSERT INTO Empleado(CI, Nombre, Apellido, Contraseña) VALUE (" + ci + ", \'" + nombre + "\', \'"+ apellido + "\', SHA1(\'" + pass + "\'));";
			System.out.println(sql);
			preparedStmt = cn.prepareStatement(sql);
			preparedStmt.execute();
			
		}catch (SQLException r){
			System.out.println(r);
			return false;
		}
		return true;
	}
	
	/**
     * Este metodo permite eliminar este empleado de la base de datos
     */
	public boolean delete() {
		// Comprobar si el usuario existe
		try {
			st = cn.createStatement();
			rs = st.executeQuery("SELECT * FROM empleado WHERE CI="+this.ci+";");
			System.out.println(rs);
		} catch (SQLException r) {
			System.out.println(r);
			// TODO: handle exception
		}
		// Eliminar el usuario
		try {
			String sql = "DELETE FROM empleado WHERE `CI` = "+ci+"";
			System.out.println(sql);
			preparedStmt = cn.prepareStatement(sql);
			preparedStmt.execute();
			
		}catch (SQLException r){
			System.out.println(r);
			return false;
		}
		// Eliminar persona
		try {
			String sql = "DELETE FROM persona WHERE `CI` = "+ci+"";
			System.out.println(sql);
			preparedStmt = cn.prepareStatement(sql);
			preparedStmt.execute();
			
		}catch (SQLException r){
			System.out.println(r);
			return false;
		}
		return true;
	}
}