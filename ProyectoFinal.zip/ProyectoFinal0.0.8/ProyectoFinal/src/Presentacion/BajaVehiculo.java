package Presentacion;
import Persistencia.Vehiculo;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Persistencia.ConectorBD;

import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import java.awt.BorderLayout;
import javax.swing.JButton;

/**
 * Esta clase contiene la ventana que permite a un empleado dar de baja un vehículo
 */
public class BajaVehiculo extends JFrame implements ActionListener {

	int cedula;
	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;
	PreparedStatement preparedStmt;
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JButton btnRegresar;
	private JButton btnBaja;
	
	/**
	 * Esta clase contiene la ventana que permite a un empleado dar de alta un vehículo
	 */
	public BajaVehiculo(int ci) {
		cn = bases.conectar();
		cedula = ci;
		this.setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100,290, 188);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		getContentPane().setLayout(null);
		
		JTextPane txtpnVehiculo = new JTextPane();
		txtpnVehiculo.setBounds(28, 11, 223, 23);
		txtpnVehiculo.setText("ID del vehiculo");
		txtpnVehiculo.setEditable(false);
		getContentPane().add(txtpnVehiculo);
		
		textField = new JTextField();
		textField.setBounds(28, 45, 223, 23);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		btnBaja = new JButton("Dar de baja");
		btnBaja.setBounds(28, 79, 223, 23);
		getContentPane().add(btnBaja);
		btnBaja.addActionListener(this);
		
		btnRegresar = new JButton("Regresar");
		btnRegresar.setBounds(28, 113, 223, 23);
		getContentPane().add(btnRegresar);
		btnRegresar.addActionListener(this);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)) {
			this.dispose();
			VentanaEmpleado ventanaempleado= new VentanaEmpleado(cedula);
		}
		
		if (e.getSource().equals(btnBaja)) {
			if (!textField.getText().isBlank()) {
				int id = Integer.parseInt(textField.getText());
				Vehiculo vehiculo = new Vehiculo(id);
				vehiculo.delete();
					
			}
		}
		
	}
}
