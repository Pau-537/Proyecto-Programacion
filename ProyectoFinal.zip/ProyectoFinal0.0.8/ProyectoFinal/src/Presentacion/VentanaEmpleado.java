package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.Color;

/**
 * Esta clase contiene la ventana que es mostrada al usuario al registrarse como empleado
 */
public class VentanaEmpleado extends JFrame implements ActionListener {

	public static int cedula;
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtBienvenidoEmpleado;
	private JButton btnDarAltaVehiculo;
	private JButton btnDarBajaVehiculo;
	private JButton btnListaDeVehiculos;
	private JButton btnSalir;

	/**
	 * Constructor de la clase
	 * @param ci La cedula del empleado
	 */
	public VentanaEmpleado(int ci) {
		cedula = ci;
		this.setVisible(true);         
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtBienvenidoEmpleado = new JTextField();
		txtBienvenidoEmpleado.setEditable(false);
		txtBienvenidoEmpleado.setText("BIENVENIDO EMPLEADO");
		txtBienvenidoEmpleado.setHorizontalAlignment(SwingConstants.CENTER);
		txtBienvenidoEmpleado.setBounds(119, 40, 185, 20);
		contentPane.add(txtBienvenidoEmpleado);
		txtBienvenidoEmpleado.setColumns(10);
		
		btnDarAltaVehiculo = new JButton("Dar alta vehiculo");
		btnDarAltaVehiculo.setBounds(119, 71, 185, 23);
		contentPane.add(btnDarAltaVehiculo);
		btnDarAltaVehiculo.addActionListener(this);
		
		btnDarBajaVehiculo = new JButton("Dar baja vehiculo");
		btnDarBajaVehiculo.setBounds(119, 105, 185, 23);
		contentPane.add(btnDarBajaVehiculo);
		btnDarBajaVehiculo.addActionListener(this);
		
		btnListaDeVehiculos = new JButton("Lista de vehiculos");
		btnListaDeVehiculos.setBounds(119, 139, 185, 23);
		contentPane.add(btnListaDeVehiculos);
		btnListaDeVehiculos.addActionListener(this);
		
		btnSalir = new JButton("Cerrar sesion");
		btnSalir.setForeground(Color.BLACK);
		btnSalir.setBounds(150, 191, 130, 23);
		contentPane.add(btnSalir);
		btnSalir.addActionListener(this);
	}
	
	
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnDarAltaVehiculo)){
			this.dispose();
			AltaVehiculo alta = new AltaVehiculo(cedula);
	}
		if (e.getSource().equals(btnDarBajaVehiculo)){
			this.dispose();
			BajaVehiculo baja = new BajaVehiculo(cedula);
	}
		if (e.getSource().equals(btnListaDeVehiculos)){
			this.dispose();
			ListadoVehiculos listado = new ListadoVehiculos(cedula);	
	}
		if (e.getSource().equals(btnSalir)) {
			this.dispose();
			VentanaPrincipal ventanaprincipal = new VentanaPrincipal();	
		}
}
}
