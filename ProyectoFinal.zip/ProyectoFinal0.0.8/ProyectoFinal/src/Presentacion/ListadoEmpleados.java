package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import Persistencia.ConectorBD;

/**
 * Esta clase contiene la ventana en la cual se muestra el listado de los empleados del sistema
 */
public class ListadoEmpleados extends JFrame implements ActionListener{
	
	ConectorBD bases = new ConectorBD();
	Connection cn = null;
	Statement st = null;
	ResultSet rs = null;
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtListaDeEmpleados;
	private JButton btnRegresar;
	private JTable table;

	Object[][] empleados = new Object[0][0];
	int cantidadDeEmpleados = 0;
	
	public ListadoEmpleados() {
		cn = bases.conectar();
		this.setVisible(true);         
		setResizable(false);		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtListaDeEmpleados = new JTextField();
		txtListaDeEmpleados.setEditable(false);
		txtListaDeEmpleados.setText("LISTA DE EMPLEADOS");
		txtListaDeEmpleados.setHorizontalAlignment(SwingConstants.CENTER);
		txtListaDeEmpleados.setBounds(135, 11, 153, 20);
		contentPane.add(txtListaDeEmpleados);
		txtListaDeEmpleados.setColumns(10);
		
		btnRegresar = new JButton("REGRESAR");
		btnRegresar.setBounds(135, 206, 153, 23);
		contentPane.add(btnRegresar);
		
		
		
		try {
			st = cn.createStatement();
			rs = st.executeQuery("SELECT * FROM Empleado");
			
			while(rs.next()) {
				cantidadDeEmpleados = rs.getRow();
			}
			
			empleados = new Object[cantidadDeEmpleados][3];
			
			int i = 0;
			rs = st.executeQuery("SELECT * FROM Empleado");
			
			while(rs.next()) {
				empleados[i][0] = rs.getString(2);
				empleados[i][1] = rs.getString(3);
				empleados[i][2] = rs.getInt(1);
				i++;
			}
		}catch (SQLException r) {
			System.out.println(r);
			// TODO: handle exception
		}
		
		
		
		table = new JTable();
		table.setColumnSelectionAllowed(true);
		table.setModel(new DefaultTableModel(
			empleados,
			new String[] {
				"Nombre", "Apellido", "Cedula"
			}
		) {
			private static final long serialVersionUID = 1L;

			Class[] columnTypes = new Class[] {
				String.class, String.class, int.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		table.setToolTipText("");
		table.setBounds(12, 42, 418, 153);
		contentPane.add(table);
		btnRegresar.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(btnRegresar)){
			this.dispose();
	        VentanaAdmin ventanaAdmin = new VentanaAdmin();		
	        }
	}
}
