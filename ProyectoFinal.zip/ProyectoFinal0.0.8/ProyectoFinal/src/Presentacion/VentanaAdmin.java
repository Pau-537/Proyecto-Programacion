package Presentacion;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Color;

/**
 * Esta clase contiene la ventana que es mostrada al usuario al registrarse como administrador
 */
public class VentanaAdmin extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtBienvenido;
	private JButton btnDarDeAlta;
	private JButton btnDarDeBaja;
	private JButton btnListadoEmpleado;
	private JButton btnInformacionDeEmpleados;
	private JButton btnSalir;


	public VentanaAdmin() {
		this.setVisible(true);         
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 362, 289);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		btnListadoEmpleado = new JButton("Listado empleados");
		btnListadoEmpleado.setBounds(57, 122, 238, 23);
		contentPane.add(btnListadoEmpleado);
		btnListadoEmpleado.addActionListener(this);
		
		btnInformacionDeEmpleados = new JButton("Informacion de empleados");
		btnInformacionDeEmpleados.setBounds(57, 158, 238, 23);
		contentPane.add(btnInformacionDeEmpleados);
		btnInformacionDeEmpleados.addActionListener(this);
		
		txtBienvenido = new JTextField();
		txtBienvenido.setHorizontalAlignment(SwingConstants.CENTER);
		txtBienvenido.setEditable(false);
		txtBienvenido.setText("BIENVENIDO ADMINISTRADOR");
		txtBienvenido.setBounds(57, 23, 238, 20);
		contentPane.add(txtBienvenido);
		txtBienvenido.setColumns(10);
		
		btnDarDeAlta = new JButton("Dar de alta ");
		btnDarDeAlta.setBounds(57, 54, 238, 23);
		contentPane.add(btnDarDeAlta);
		btnDarDeAlta.addActionListener(this);
		
		btnDarDeBaja = new JButton("Dar de baja");
		btnDarDeBaja.setBounds(57, 88, 238, 23);
		contentPane.add(btnDarDeBaja);
		btnDarDeBaja.addActionListener(this);
		
		btnSalir = new JButton("Cerrar sesion");
		btnSalir.setForeground(Color.BLACK);
		btnSalir.setBounds(86, 201, 181, 23);
		contentPane.add(btnSalir);
		btnSalir.addActionListener(this);
		
	}
	
	public void actionPerformed(ActionEvent e) {
			if (e.getSource().equals(btnDarDeAlta)){
				this.dispose();
				DarDeAlta alta = new DarDeAlta();
		}
			if (e.getSource().equals(btnDarDeBaja)){
				this.dispose();
				DarDeBaja baja = new DarDeBaja();
		}
			if (e.getSource().equals(btnListadoEmpleado)){
				this.dispose();
				ListadoEmpleados listado = new ListadoEmpleados();	
		}
			if (e.getSource().equals(btnInformacionDeEmpleados)){
				this.dispose();
				InfoEmpleados info = new InfoEmpleados();
		}
			if (e.getSource().equals(btnSalir)){
				this.dispose();
				VentanaPrincipal ventanaprincipal = new VentanaPrincipal();
		}
	}
}
