DROP DATABASE baseNARP;
CREATE DATABASE baseNARP;
USE baseNARP;

CREATE TABLE Persona(
    CI int PRIMARY KEY,
);

CREATE TABLE Empleado(
    CI int,
    Nombre varchar(30) NOT NULL,
    Apellido varchar(30) NOT NULL,
    Contraseña varchar(30) NOT NULL,
    PRIMARY KEY(CI)
);

CREATE TABLE Administrador (
    CI int,
    Nombre varchar(30) NOT NULL,
    Apellido varchar(30) NOT NULL,
    Contraseña varchar(30) NOT NULL,
    PRIMARY KEY(CI)
);

CREATE TABLE Vehiculo(
    ID int,
    Fecha_de_ingreso DATABASE;
    Marca varchar(50),
    Anio smallint NOT NULL,
    CI int NOT NULL,
);

ALTER TABLE Empleado ADD FOREIGN KEY (CI) REFERENCES Persona (CI);
ALTER TABLE Administrador ADD FOREIGN KEY (CI) REFERENCES Persona (CI);
ALTER TABLE Vehiculo ADD FOREIGN KEY (CI) REFERENCES Persona (CI);
