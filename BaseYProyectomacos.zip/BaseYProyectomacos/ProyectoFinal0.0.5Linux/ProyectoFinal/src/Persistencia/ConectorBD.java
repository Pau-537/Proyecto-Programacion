package Persistencia;


 


import java.sql.Connection;


import java.sql.DriverManager;


import java.sql.Statement;


import java.sql.PreparedStatement;


import java.sql.ResultSet;


import java.sql.SQLException;


 


/**


 * Conector de la base de datos, utilizar como superclase.


 */


public class ConectorBD {


 /*


 * Se agrega serverTimezone para evitar errores con el horario de la zona si aparece.


 *


 * jdbc:mysql://:/de Datos>?serverTimezone=Horaria>


 *


 * Mas información:https://es.stackoverflow.com/questions/362088/error-en-conexion-sql-java-sql-sqlexception-the-server-time-zone-value-hora


 */


 


 //Constantes


 private final String BD_DRIVER = "com.mysql.cj.jdbc.Driver"; //Controlador de la base de datos


 private final String BD_HOST = "jdbc:mysql://localhost:3306/baseNARP"; //URL de la base de datos


 private final String BD_USUARIO = "root"; //Usuario de la base de datos


 private final String BD_CLAVE = ""; //Clave del usuario de la base de datos


 


 //Atributos


 protected Connection conexion; //Conector de la base de datos


 protected Statement sentenciaSQL; //Preparador de sentencias fijas


 protected PreparedStatement sentenciaPreparadaSQL; //Preparador de sentencias variables
  

 protected ResultSet resultadosSQL; //Guarda los resultados de una consulta SQL


 


 /**


 * Establece la conexión con la Base de Datos.
 * @return 


 */


 public Connection conectar() {


	 try {
	
	
		 Class.forName(BD_DRIVER);
		
		
		 conexion = DriverManager.getConnection(BD_HOST, BD_USUARIO, BD_CLAVE);
		
		
		 System.out.println("Conexión establecida exitosamente...");
	
	
	 } catch (ClassNotFoundException | SQLException e) {
	
	
		 System.out.println("Error #1: Se encontraron problemas al conectar con la base de datos...\n***********\n");
		
		
		 e.printStackTrace();
	
	
	 }
	return conexion;


 }


 


 /**


 * Desconecta la base de datos de manera secuencial.


 */


 protected void desconectar() {


	 try {
	
	
		 if (resultadosSQL != null)
		
		
			 resultadosSQL.close();
	
	
		 if (sentenciaSQL != null)
	
	
			 	sentenciaSQL.close();
	
	
		 if(sentenciaPreparadaSQL != null)
	
	
			 	sentenciaPreparadaSQL.close();
	
	
		 if (conexion != null)
	
	
			 	conexion.close();
	
	
	 
	
	
		 System.out.println("Desconexión realizada exitosamente...");
	
	
	 } catch (Exception e) {
	
	
		 System.out.println("Error #2: Se encontraron problemas al cerrar la conexión con la base de datos...\n***********\n");
	
	
		 e.printStackTrace();
	
	
	 }
	
	
}


}


 

