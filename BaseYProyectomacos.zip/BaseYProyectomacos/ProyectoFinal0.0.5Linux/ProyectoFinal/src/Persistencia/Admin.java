package Persistencia;

public class Admin {

}
